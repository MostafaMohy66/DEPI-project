import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.io.FileHandler;
import java.io.File;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

import java.io.IOException;
import java.time.Duration;

public class Test {

    WebDriver driver ;
    @BeforeTest
    public void OpenBrowser()
    {
        System.setProperty("webdriver.gecko.driver","E:\\geckodriver.exe");
        driver = new FirefoxDriver();
        driver.get("https://www.demoblaze.com/");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
    }


   /* @DataProvider(name = "testdata")
    public static Object[][] userdata() {
        return new Object[][]{
                {"andro_260@yahoo.com", "0114639758123800536"},
                {"andro_260@yahoo.com", "asadsd"}

        };
    }*/

    @org.testng.annotations.Test(priority = 1)
    public void Sign_Up()
    {
        WebElement text= driver.findElement(By.cssSelector("#signin2"));
        text.click();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }


      WebElement usern=driver.findElement(By.cssSelector("#sign-username"));
        usern.sendKeys("Ahmed4334");

        WebElement pass= driver.findElement(By.cssSelector("#sign-password"));
        pass.sendKeys("1234");

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        WebElement enter=driver.findElement(By.cssSelector("#signInModal > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > button:nth-child(2)"));
        enter.click();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        driver.switchTo().alert().accept();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }


    }

    @org.testng.annotations.Test(priority = 2)
    public void Sign_In(){
        WebElement menu=driver.findElement(By.cssSelector("#login2"));
        menu.click();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        WebElement logu=driver.findElement(By.cssSelector("#loginusername"));
        logu.sendKeys("Ahmed4334");
        WebElement logp= driver.findElement(By.cssSelector("#loginpassword"));
        logp.sendKeys("1234");
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        WebElement enter= driver.findElement(By.cssSelector("#logInModal > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > button:nth-child(2)"));
        enter.click();


        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

    }

    @org.testng.annotations.Test(priority = 3)
    public void addItem(){

        WebElement nframes= driver.findElement(By.cssSelector("div.col-md-6:nth-child(1) > div:nth-child(1) > div:nth-child(2) > h4:nth-child(1) > a:nth-child(1)"));
        nframes.click();
        WebElement nnframes=driver.findElement(By.cssSelector("a.btn"));
        nnframes.click();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        driver.switchTo().alert().accept();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }


    }

    @org.testng.annotations.Test(priority = 4)
    public void deleteItem(){
        WebElement delitem= driver.findElement(By.cssSelector("#cartur"));
        delitem.click();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        WebElement browse= driver.findElement(By.cssSelector(".success > td:nth-child(4) > a:nth-child(1)"));
        browse.click();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }






    }

   /* @org.testng.annotations.Test(priority = 5)
    public void Dropdown(){
        WebElement drop=driver.findElement(By.cssSelector("#content > ul:nth-child(4) > li:nth-child(11) > a:nth-child(1)"));
        drop.click();
        WebElement select=driver.findElement(By.cssSelector("#dropdown"));
        select.click();
        WebElement option=driver.findElement(By.cssSelector("#dropdown > option:nth-child(3)"));
        option.click();

        driver.navigate().back();
    }

    @org.testng.annotations.Test(priority = 6)
    public void digesAuth()
    {
        WebElement diAuth=driver.findElement(By.cssSelector("#content > ul:nth-child(4) > li:nth-child(8) > a:nth-child(1)"));
        diAuth.click();


        Alert alert=driver.switchTo().alert();
        // alert.sendKeys("admin");
     /*   try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }


        String text= alert.getText();
        System.out.println(text);
        alert.sendKeys("admin"+ Keys.TAB+"admin");


        // alert.sendKeys("admin");
        alert.accept();
    }

    @org.testng.annotations.Test
    public void  loading_wait_element()
    {
        WebElement load=driver.findElement(By.cssSelector("#content > ul:nth-child(4) > li:nth-child(14) > a:nth-child(1)"));
        load.click();
        WebElement load2=driver.findElement(By.cssSelector(".example > a:nth-child(5)"));
        load2.click();
        WebElement B_load=driver.findElement(By.cssSelector("#start > button:nth-child(1)"));
        B_load.click();

        WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(10));

        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#finish > h4:nth-child(1)")));






    }

    @org.testng.annotations.Test
    public void screenshot()
    {

        File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

        // Save the screenshot to a desired location
        File destinationFile = new File("path/to/screenshot.png");
        try {
            FileHandler.copy(screenshot, new File("E:\\Mine\\testing\\Course\\screenshot.png"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
    @org.testng.annotations.Test
    public void drop_select()
    {

        WebElement drop= driver.findElement(By.cssSelector("#content > ul:nth-child(4) > li:nth-child(11) > a:nth-child(1)"));
        drop.click();

        Select drpCountry = new Select(driver.findElement(By.id("dropdown")));
        drpCountry.selectByVisibleText("Option 1");

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        drpCountry.selectByVisibleText("Option 2");

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        //can select by index or other ways can found through this link
        //https://www.guru99.com/select-option-dropdown-selenium-webdriver.html

    }
*/

    @AfterTest
    public void CloseBrowser()
    {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.quit();
    }



}

