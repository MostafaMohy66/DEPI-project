package Login;


import Base.BaseTests;
import Pages.Login;
import Pages.Registerpage;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.FileNotFoundException;

import io.qameta.allure.Description;
import io.qameta.allure.Story;

import static org.testng.Assert.assertTrue;

public class Logout extends BaseTests {

    @Test(testName="Test1")
    @Description ("Successfull logout")
    @Story("Logout")
    public void SuccesfulLogout ()
    {

        Login logout =homepage.clickonLoginonbutton();
        logout.insertfirstname("Andrew1234");
        logout.insertpassword("1234");
        logout.clickLogin();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        logout.Logout();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        String actualResult =driver.findElement(By.cssSelector("#signin2")).getText();
        String expectedResult ="Sign";
        assertTrue(actualResult.contains(expectedResult));





    }


}
