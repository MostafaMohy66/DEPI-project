package Login;

import Base.BaseTests;
import Pages.Login;
import Pages.Registerpage;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import java.io.FileNotFoundException;

import static org.testng.Assert.assertTrue;

import io.qameta.allure.Description;
import io.qameta.allure.Story;

public class ValidLogin extends BaseTests {
    @Test(testName="Test1")
    @Description ("Test Successfull login")
    @Story("Valid login")
    public void testsuccessfullogin() throws FileNotFoundException {
        Login loginpage =homepage.clickonLoginonbutton();
        loginpage.insertfirstname("Andrew1234a");
        loginpage.insertpassword("1234a");
        loginpage.clickLogin();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

     /*   String actualResult =driver.findElement(By.cssSelector("#nameofuser")).getText();
        String expectedResult ="Andrew";
        assertTrue(actualResult.contains(expectedResult));
*/

    }

}
