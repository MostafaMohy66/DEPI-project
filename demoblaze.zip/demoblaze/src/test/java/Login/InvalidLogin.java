package Login;

import Base.BaseTests;
import Pages.Login;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import java.io.FileNotFoundException;

import static org.testng.Assert.assertTrue;

import io.qameta.allure.Description;
import io.qameta.allure.Story;

public class InvalidLogin extends BaseTests {

    @Test(testName="Test1")
    @Description ("Test Wrong Password")
    @Story("Invalid login")

    public void testWrongpassword() throws FileNotFoundException {
        Login loginpage =homepage.clickonLoginonbutton();
        loginpage.insertfirstname("Andrew1234");
        loginpage.insertpassword("1235");
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        loginpage.clickLogin();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        String actualresult = driver.switchTo().alert().getText();
        String expectedResult ="Wrong";
        assertTrue(actualresult.contains(expectedResult));


    }

    @Test(testName="Test2")
    @Description ("Test Wrong username")
    @Story("Invalid login")
    public void testWrongusername() throws FileNotFoundException {
        Login loginpage =homepage.clickonLoginonbutton();
        loginpage.insertfirstname("Andrew999");
        loginpage.insertpassword("1235");
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        loginpage.clickLogin();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        String actualresult = driver.switchTo().alert().getText();
        String expectedResult ="not exist";
        assertTrue(actualresult.contains(expectedResult));


    }

    @Test(testName="Test3")
    @Description ("Test uppercase password")
    @Story("Invalid login")
    public void testuppercasePassword() throws FileNotFoundException {
        Login loginpage =homepage.clickonLoginonbutton();
        loginpage.insertfirstname("Andrew1234a");
        loginpage.insertpassword("1234A");
        loginpage.clickLogin();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

      /*  String actualresult = driver.switchTo().alert().getText();
        String expectedResult ="Please fill out Username and Password";
        assertTrue(actualresult.contains(expectedResult));
*/

    }

    @Test(testName="Test4")
    @Description ("Test Empty email and password")
    @Story("Invalid login")
    public void testEmptyemailandpassword() throws FileNotFoundException {
        Login loginpage =homepage.clickonLoginonbutton();

        loginpage.clickLogin();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        String actualresult = driver.switchTo().alert().getText();
        String expectedResult ="Please fill";
        assertTrue(actualresult.contains(expectedResult));


    }

    @Test(testName="Test5")
    @Description ("Test Empty Email")
    @Story("Invalid login")
    public void testEmptyemail() throws FileNotFoundException {
        Login loginpage =homepage.clickonLoginonbutton();
        loginpage.insertfirstname("");
        loginpage.insertpassword("1235");
        loginpage.clickLogin();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        String actualresult = driver.switchTo().alert().getText();
        String expectedResult ="Please fill";
        assertTrue(actualresult.contains(expectedResult));


    }

    @Test(testName="Test6")
    @Description ("Test Empty Password")
    @Story("Invalid login")
    public void testEmptypassword() throws FileNotFoundException {
        Login loginpage =homepage.clickonLoginonbutton();
        loginpage.insertfirstname("Andrew1234");
        loginpage.insertpassword("");
        loginpage.clickLogin();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        String actualresult = driver.switchTo().alert().getText();
        String expectedResult ="Please fill";
        assertTrue(actualresult.contains(expectedResult));


    }




}



