package Base;

import Pages.Cart;
import Pages.Homepage;
//import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxDriverService;
import org.openqa.selenium.remote.service.DriverService;
import org.testng.annotations.*;

import java.time.Duration;

public class BaseTests {
    public WebDriver driver;
    public Homepage homepage;


    @BeforeMethod
    public void setup()
    {
        //FirefoxDriverService service =new FirefoxDriverService.Builder().


        System.setProperty("webdriver.gecko.driver","E:\\geckodriver.exe");
        driver = new FirefoxDriver();
        driver.get("https://www.demoblaze.com/");
                homepage =new Homepage(driver);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
    }

    @AfterMethod
    public void Teardown(){driver.quit();}

}
