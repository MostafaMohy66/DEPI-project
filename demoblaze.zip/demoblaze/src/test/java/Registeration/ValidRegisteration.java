package Registeration;

import Base.BaseTests;
import Pages.Registerpage;
import org.testng.annotations.Test;

import java.io.FileNotFoundException;

import static org.testng.Assert.assertTrue;

import io.qameta.allure.Description;
import io.qameta.allure.Story;

public class ValidRegisteration extends BaseTests {

    @Test(testName="Test1")
    @Description ("Successfull Registeration")
    @Story("Valid Registeration")
    public void testsucessfullregister()  {


        Registerpage registerpage = homepage.clickonRegisterationbutton();
        registerpage.insertfirstname("qatarop78");
        registerpage.insertpassword("9965");
        registerpage.clickRegister();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

      /*  String actualresult = driver.switchTo().alert().getText();
        String expectedresult ="successful";
        assertTrue(actualresult.contains(expectedresult));
*/



    }



}
