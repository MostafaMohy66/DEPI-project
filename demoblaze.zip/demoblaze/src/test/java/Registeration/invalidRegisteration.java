package Registeration;

import Base.BaseTests;
import Pages.Registerpage;
import org.testng.annotations.Test;

import java.io.FileNotFoundException;

import static org.testng.Assert.assertTrue;

import io.qameta.allure.Description;
import io.qameta.allure.Story;

public class invalidRegisteration extends BaseTests {


    @Test(testName="Test1")
    @Description ("Register with no Username")
    @Story("Invalid Registeration")
    public void testregisterwithoutusername() throws FileNotFoundException{
        Registerpage registerpage =homepage.clickonRegisterationbutton();
        registerpage.insertfirstname("");
        registerpage.insertpassword("1234");
        registerpage.clickRegister();

        String actualResult =driver.switchTo().alert().getText();
        String expectedResult ="Please fill out Username and Password";
        assertTrue(actualResult.contains(expectedResult));


    }


    @Test(testName="Test2")
    @Description ("Register with no Password")
    @Story("Invalid Registeration")
    public void testwithoutpassword()
    {
        Registerpage registerpage =homepage.clickonRegisterationbutton();
        registerpage.insertfirstname("OptimusPrime");
        registerpage.insertpassword("");
        registerpage.clickRegister();

        String actualResult =driver.switchTo().alert().getText();
        String expectedResult ="Please fill out Username and Password";
        assertTrue(actualResult.contains(expectedResult));

    }

    @Test(testName="Test3")
    @Description ("Register with same Email")
    @Story("Invalid Registeration")
    public void testregisterwithsameemail() throws FileNotFoundException{

       Registerpage registerpage =homepage.clickonRegisterationbutton();
       registerpage.insertfirstname("Andrew");
       registerpage.insertpassword("1234");
       registerpage.clickRegister();

       try {
           Thread.sleep(2000);
       } catch (InterruptedException e) {
           throw new RuntimeException(e);
       }
/*       String actualResult = driver.switchTo().alert().getText();
       String expectedResult ="exist";
       assertTrue(actualResult.contains(expectedResult));
*/
   }


    @Test(testName="Test4")
    @Description ("Test Uppercase Register")
    @Story("Invalid Registeration")
    public void testUPPERCASEregister()  {


        Registerpage registerpage = homepage.clickonRegisterationbutton();
        registerpage.insertfirstname("OMAN");
        registerpage.insertpassword("9968");
        registerpage.clickRegister();


    /*    String actualresult = driver.switchTo().alert().getText();
        String expectedresult ="exist";
        assertTrue(actualresult.contains(expectedresult));
*/



    }

    @Test(testName="Test1")
    @Description ("Register with no Email or Password")
    @Story("Invalid Registeration")
    public void testregisterwithoutemailandpassword() throws FileNotFoundException{
        Registerpage registerpage =homepage.clickonRegisterationbutton();
        registerpage.insertfirstname("");
        registerpage.insertpassword("");
        registerpage.clickRegister();

        String actualResult =driver.switchTo().alert().getText();
        String expectedResult ="Please fill out Username and Password";
        assertTrue(actualResult.contains(expectedResult));


    }

    @Test(testName="Test1")
    @Description ("Register with Email and Password special character")
    @Story("Invalid Registeration")
    public void testregisterwithemailandpasswordspecialcharacters() throws FileNotFoundException{
        Registerpage registerpage =homepage.clickonRegisterationbutton();
        registerpage.insertfirstname("xgate@#$%");
        registerpage.insertpassword("xgate@#$%");
        registerpage.clickRegister();

/*        String actualResult =driver.switchTo().alert().getText();
        String expectedResult ="Please enter suitable format";
        assertTrue(actualResult.contains(expectedResult));
*/

    }










}
