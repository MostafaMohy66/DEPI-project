package Cart;

import Base.BaseTests;
import Pages.Cart;
import Pages.Homepage;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import java.io.FileNotFoundException;

import static org.testng.Assert.assertTrue;

import io.qameta.allure.Description;
import io.qameta.allure.Story;





public class AddtoCart extends BaseTests {


    @Test(testName="Test1",priority = 1)
    @Description ("Add item")
    @Story("Add to cart")
    public void additem() throws FileNotFoundException{
        Homepage add = homepage;
        add.additem();

        Cart Cart =homepage.clickonCartbutton();



    /*    String actualResult =driver.findElement(By.cssSelector(".success > td:nth-child(2)")).getText();
        String expectedResult ="s6";
        assertTrue(actualResult.contains(expectedResult));
*/
    }

    @Test(testName="Test2",priority = 2)
    @Description ("Add 2 items same type")
    @Story("Add to cart")
    public void  add2itemsSametype()
    {
        Homepage add=homepage;
        add.add2itemsSametype();

        Cart Cart =homepage.clickonCartbutton();
       try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

     /*   String actualResult1 =driver.findElement(By.cssSelector("tr.success:nth-child(2) > td:nth-child(2)")).getText();
        String expectedResult1 ="HTC";
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        assertTrue(actualResult1.contains(expectedResult1));
        String actualResult =driver.findElement(By.cssSelector("tr.success:nth-child(1) > td:nth-child(2)")).getText();
        String expectedResult ="s6";
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        assertTrue(actualResult.contains(expectedResult));


       String ActualsumPrice= Cart.checkprice();
        String ExpetedsumPrice="Equal";
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
       assertTrue(ActualsumPrice.contains(ExpetedsumPrice));*/
    }

    @Test(testName="Test3",priority = 3)
    @Description ("Add 2 items different type")
    @Story("Add to cart")
    public void  add2itemsdifferentType()
    {
        Homepage add=homepage;
        add.add2itemsdifferenttype();

        Cart Cart =homepage.clickonCartbutton();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

      /*  String actualResult1 =driver.findElement(By.cssSelector("tr.success:nth-child(2) > td:nth-child(2)")).getText();
        String expectedResult1 ="HTC";
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        assertTrue(actualResult1.contains(expectedResult1));
        String actualResult =driver.findElement(By.cssSelector("tr.success:nth-child(1) > td:nth-child(2)")).getText();
        String expectedResult ="s6";
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        assertTrue(actualResult.contains(expectedResult));

        String ActualsumPrice= Cart.checkprice();
        String ExpetedsumPrice="Equal";
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        assertTrue(ActualsumPrice.contains(ExpetedsumPrice));

*/

    }






}
