package Cart;

import Base.BaseTests;
import Pages.Cart;
import Pages.Homepage;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import java.io.FileNotFoundException;

import static org.testng.Assert.assertTrue;

import io.qameta.allure.Description;
import io.qameta.allure.Story;

public class ManageCart extends BaseTests {


    @Test(testName="Test1")
    @Description ("delete item")
    @Story("Manage cart")
    public void deleteCartitem()
    {

        Homepage add= homepage;
        Cart cart= new Cart(driver);
        add.additem();
        add.clickonCartbutton();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

       cart.deleteFirstitem();


        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

    }


    }



