package PlaceOrder;

import Base.BaseTests;
import Pages.Cart;
import Pages.Homepage;
import org.testng.annotations.Test;

import static org.testng.Assert.assertTrue;


import io.qameta.allure.Description;
import io.qameta.allure.Story;

public class ValidPurchase extends BaseTests {

    @Test(testName="Test1")
    @Description ("Purchase with no mandatory data")
    @Story("Valid Purchase")
    public void Validpurchasewithonlymandatorydata()
    {
        Homepage add= homepage;
        Cart Purchase = new Cart(driver);
        add.additem();
        add.clickonCartbutton();
        Purchase.ClickPObutton();
        Purchase.Placeorderwithname("Ahmed");
        Purchase.Placeordercreditcard("212154546");
        Purchase.ClickonPurchaseButton();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

    /*    String actualresult = Purchase.POreplySuccess();
        String expectedResult ="Thank you";
        assertTrue(actualresult.contains(expectedResult));

        String actualresultName = Purchase.POname();
        String expectedResultName ="Ahmed";
        assertTrue(actualresultName.contains(expectedResultName));

        String ActualsumPrice= Purchase.checpriceonBill();
        String ExpetedsumPrice="Equal";
        assertTrue(ActualsumPrice.contains(ExpetedsumPrice));

*/
    }

    @Test(testName="Test2")
    @Description ("Purchase with all data")
    @Story("Valid Purchase")
    public void ValidpurchasewithAlldata()
    {
            Homepage add= homepage;
            Cart Purchase = new Cart(driver);
            add.additem();
            add.clickonCartbutton();
            Purchase.ClickPObutton();
            Purchase.Placeorderwithname("Ahmed");
           Purchase.Placeordercreditcard("212154546");
           Purchase.Placeorderwithcountry("Egypt");
            Purchase.Placeorderwithcity("Cairo");
            Purchase.Placeorderwithmonth("7");
            Purchase.Placeorderwithyear("2028");
            Purchase.ClickonPurchaseButton();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

          /*  String actualresult = Purchase.POreplySuccess();
            String expectedResult ="Thank you";
            assertTrue(actualresult.contains(expectedResult));

            String actualresultName = Purchase.POname();
            String expectedResultName ="Ahmed";
            assertTrue(actualresultName.contains(expectedResultName));


            String ActualsumPrice= Purchase.checpriceonBill();
            String ExpetedsumPrice="Equal";
            assertTrue(ActualsumPrice.contains(ExpetedsumPrice));
*/

        }

    }

