package PlaceOrder;

import Base.BaseTests;
import Pages.Cart;
import Pages.Homepage;
import org.testng.annotations.Test;

import static org.testng.Assert.assertTrue;

import io.qameta.allure.Description;
import io.qameta.allure.Story;

public class InvalidPurchase extends BaseTests {

    @Test(testName="Test1")
    @Description ("Purchase with no data")
    @Story("Invalid Purchase")
    public void purchasewithnodata()
    {
        Homepage add= homepage;
        Cart cart= new Cart(driver);
        add.additem();
        add.clickonCartbutton();
        cart.ClickPObutton();
        cart.ClickonPurchaseButton();


        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        String actualresult = driver.switchTo().alert().getText();
        String expectedResult ="Please fill out Name and Creditcard";
        assertTrue(actualresult.contains(expectedResult));
    }

    @Test(testName="Test2")
    @Description ("Purchase with no Name")
    @Story("Invalid Purchase")
    public void purchasewithoutName()
    {
        Homepage add= homepage;
        Cart Purchase= new Cart(driver);
        add.additem();
        add.clickonCartbutton();

        Purchase.ClickPObutton();


        Purchase.Placeordercreditcard("1212154");
        Purchase.ClickonPurchaseButton();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        String actualresult =Purchase.POreply();
        String expectedResult ="Please fill";
        assertTrue(actualresult.contains(expectedResult));



    }


    @Test(testName="Test3")
    @Description ("Purchase with no credit card")
    @Story("Invalid Purchase")
    public void purchasewithoutcredit()
    {
        Homepage add= homepage;
        Cart Purchase= new Cart(driver);
        add.additem();
        add.clickonCartbutton();

        Purchase.ClickPObutton();


        Purchase.Placeorderwithname("Andrew");
        Purchase.ClickonPurchaseButton();
        String actualresult =Purchase.POreply();
        String expectedResult ="Please fill";
        assertTrue(actualresult.contains(expectedResult));



    }

}
