package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Registerpage {

    WebDriver driver;
    public Registerpage(WebDriver driver) {
        this.driver=driver;
    }

    private By Firstnamefield = By.cssSelector("#sign-username");
    private By Lastnamefield = By.id("Lastname");
    private By Emailfield = By.id("Email");
    private By Passwordfield = By.cssSelector("#sign-password");
    private By ConfirmPasswordfield = By.id("ConfirmPassword");
    private By Companyfield = By.id("Company");
    private By Genderfield = By.id("Gender");
    private By Registerbutton = By.cssSelector("#signInModal > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > button:nth-child(2)");
    private By validation = By.className("Result");
    private By errormessageinvalidemail = By.xpath("Passwod");
    private By errormessageemail = By.xpath("Passwod");


    public String ValidationMessage(){
        String text =driver.findElement(validation).getText();
        return text;
    }

    public String errormessage1(){
        String text=driver.findElement(errormessageinvalidemail)
                .getText();
        return text;
    }
    public String errormessage2 (){
        String text =driver.findElement(errormessageemail).getText();
        return text;
    }
    public void clickRegister(){
        driver.findElement(Registerbutton).click();
    }

    public void clickGender(){
        driver.findElement(Genderfield).click();
    }

    public void insertfirstname (String Firstname) {driver.findElement(Firstnamefield).sendKeys(Firstname);}
    public void lastfirstname (String Lastname) {driver.findElement(Lastnamefield).sendKeys(Lastname);}

    public void insertpassword (String Password) {driver.findElement(Passwordfield).sendKeys(Password);}

    public void insertconfirmpassword (String ConfirmPassword) {driver.findElement(ConfirmPasswordfield).sendKeys(ConfirmPassword);}
    public void insertEmail (String Email) {driver.findElement(Emailfield).sendKeys(Email);}

    public void insertcompany (String Company) {driver.findElement(Companyfield).sendKeys(Company);}















}
