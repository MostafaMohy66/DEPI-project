package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Login {
  WebDriver driver;
    public Login(WebDriver driver) {
        this.driver=driver;
    }

    private By Firstnamefield = By.cssSelector("#loginusername");
    private By Passwordfield = By.cssSelector("#loginpassword");
    private By Loginbutton = By.cssSelector("#logInModal > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > button:nth-child(2)");

    private By ProfileName =By.cssSelector("#nameofuser");
    private By LogoutButton =By.cssSelector("#logout2");

    public void clickLogin(){
        driver.findElement(Loginbutton).click();
    }
    public void insertfirstname (String Firstname) {driver.findElement(Firstnamefield).sendKeys(Firstname);}

    public void insertpassword (String Password) {driver.findElement(Passwordfield).sendKeys(Password);}

    public void Logout () {driver.findElement(LogoutButton).click();}



}
