package Pages;

import net.jodah.failsafe.internal.util.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Homepage {
    WebDriver driver;

    public Homepage(WebDriver driver){

        this.driver=driver;
    }

    private By Registerationbutton= By.cssSelector("#signin2");
    private By Loginbutton= By.cssSelector("#login2");
    private By Cartbutton= By.cssSelector("#cartur");
    private By Addbutton=By.cssSelector("a.btn");
    private By Item1= By.cssSelector("div.col-md-6:nth-child(1) > div:nth-child(1) > div:nth-child(2) > h4:nth-child(1) > a:nth-child(1)");
    private By Item2=By.cssSelector("div.col-lg-4:nth-child(8) > div:nth-child(1) > div:nth-child(2) > h4:nth-child(1) > a:nth-child(1)");
    private By Item11=By.cssSelector("div.col-lg-4:nth-child(7) > div:nth-child(1) > div:nth-child(2) > h4:nth-child(1) > a:nth-child(1)");
    private By Homebutton=By.cssSelector("#nava");
    private By Firstitemdeletebutton=By.cssSelector(".success > td:nth-child(4) > a:nth-child(1)");



    public Registerpage clickonRegisterationbutton(){
        driver.findElement(Registerationbutton).click();
       return new Registerpage(driver);

    }
    public Login clickonLoginonbutton(){
        driver.findElement(Loginbutton).click();
        return new Login(driver);

    }


    public Cart clickonCartbutton(){
        driver.findElement(Cartbutton).click();
        return new Cart(driver);

    }

    public void  additem(){
        driver.findElement(Item1).click();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        driver.findElement(Addbutton).click();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        driver.switchTo().alert().accept();


        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }


    }

    public void  add2itemsdifferenttype() {
        driver.findElement(Item1).click();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        driver.findElement(Addbutton).click();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        driver.switchTo().alert().accept();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        driver.findElement(Homebutton).click();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        driver.findElement(Item2).click();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        driver.findElement(Addbutton).click();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        driver.switchTo().alert().accept();




    }


    public void  add2itemsSametype() {
        driver.findElement(Item1).click();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        driver.findElement(Addbutton).click();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        driver.switchTo().alert().accept();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        driver.findElement(Homebutton).click();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        driver.findElement(Item11).click();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        driver.findElement(Addbutton).click();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        driver.switchTo().alert().accept();


    }




}
