package Pages;

import net.jodah.failsafe.internal.util.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;



public class Cart {
    WebDriver driver;


    public Cart(WebDriver driver){

        this.driver=driver;
    }



    private By Firstitemname= By.cssSelector(".success > td:nth-child(2)");
    private By Firstitemprice=By.cssSelector("tr.success:nth-child(1) > td:nth-child(3)");
    private By Seconditemname= By.cssSelector("tr.success:nth-child(2) > td:nth-child(2)");
    private By Seconditemprice=By.cssSelector("tr.success:nth-child(2) > td:nth-child(3)");
    private By Firstitemdeletebutton= By.linkText("Delete");
    private By TotalPrice=By.cssSelector("#totalp");

    private By Placeorderbutton=By.cssSelector("button.btn:nth-child(3)");
    private By POname=By.cssSelector("#name");
    private By POcountry=By.cssSelector("#country");
    private By POcity=By.cssSelector("#city");
    private By POcreditcard=By.cssSelector("#card");
    private By POmonth=By.cssSelector("#month");
    private By POyear=By.cssSelector("#year");
    private By POpurchase=By.cssSelector("#orderModal > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > button:nth-child(2)");
    private By POreply=By.cssSelector(".sweet-alert > h2:nth-child(6)");
    private By POnamereply=By.cssSelector(".lead");







   public String checkprice()
   {


      String First = driver.findElement(Firstitemprice).getText();
      String Second= driver.findElement(Seconditemprice).getText();
      String Total=driver.findElement(TotalPrice).getText();
       try {
           Thread.sleep(2000);
       } catch (InterruptedException e) {
           throw new RuntimeException(e);
       }

      int num1= Integer.parseInt(First);
      int num2=Integer.parseInt(Second);
      int total=Integer.parseInt(Total);
       if((num1+num2)==total)
       { return "Equal";}
       else
       {return "NOT Equal";}


   }
    public void deleteFirstitem ()
    {

       driver.findElement(Firstitemdeletebutton).click();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }



    public void Placeorderwithname(String Name)
    {

        driver.findElement(POname).sendKeys(Name);

    }
    public void Placeordercreditcard(String Credit)
    {



        driver.findElement(POcreditcard).sendKeys(Credit);
    }

    public void ClickonPurchaseButton()
    {
        driver.findElement(POpurchase).click();
    }

    public void ClickPObutton()
    {
        driver.findElement(Placeorderbutton).click();
    }

    public void Placeorderwithcountry(String country)
    {
        driver.findElement(POcountry).sendKeys(country);
    }

    public void Placeorderwithcity(String city)
    {
        driver.findElement(POcity).sendKeys(city);
    }


    public void Placeorderwithmonth(String month)
    {
        driver.findElement(POmonth).sendKeys(month);
    }


    public void Placeorderwithyear (String year)
    {
        driver.findElement(POyear).sendKeys(year);
    }

    public String POreply()
    {
        String reply;
        reply = driver.switchTo().alert().getText();;
        return reply;
    }

    public String POname()
    {
        String name=driver.findElement(POnamereply).getText();
        return name;

    }

    public String checpriceonBill()
    {
        String Total=driver.findElement(TotalPrice).getText();
        String price=driver.findElement(POnamereply).getText();
        if (price==Total)
        {return "Equal";}
        else
        {return "NotEqual";}


    }

    public String POreplySuccess()
    {
        String reply;
        reply = driver.findElement(POreply).getText();
        return reply;
    }







}
